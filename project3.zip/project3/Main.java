package cu.cs.cpsc2150.project3;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Main {
	public static void main(String[] args) throws FileNotFoundException, ClassNotFoundException, IOException {
		GUI.runGUI();
	}
}
